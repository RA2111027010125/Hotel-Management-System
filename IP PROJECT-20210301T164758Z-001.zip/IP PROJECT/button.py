import tkinter as tk
from tkinter import *
from PIL import ImageTk,Image

root=tk.Tk()
root.geometry("1199x600+100+50")

photo=ImageTk.PhotoImage(file="E:\\Others\\Nithish\\IP_Project\\Login_bg.jpg")
bag_img=Label(image=photo).place(x=0,y=0,relwidth=1,relheight=1)

def add_item():
    import adding_item

def delete_item():
    import deleting_item

def update_item():
    import updating_item


add_btn=tk.Button(root,text='Add Item',command=add_item,font=("",20,"bold"))
add_btn.place(x=50,y=250, width=150, height=60)

del_btn=tk.Button(root,text='Delete Item',command=delete_item,font=("",20,"bold"))
del_btn.place(x=50,y=320, width=170, height=60)

upd_btn=tk.Button(root,text='Update Item',command=update_item,font=("",20,"bold"))
upd_btn.place(x=50,y=390, width=180, height=60)

root.mainloop()
