from tkinter import *
from tkinter import messagebox
from PIL import ImageTk,Image
class Login:
    def __init__(self,root):
        self.root=root
        self.root.title("Login")
        self.root.geometry("1199x600+100+50")
        self.root.resizable(False,False)

        #==========BG IMAGE============

        self.image = ImageTk.PhotoImage(file = "image/food.jpg")
        self.bag_img=Label(image=self.image).place(x=0,y=0,relwidth=1,relheight=1)

        #===========Login Box==============

        Login_box=Frame(self.root,bg="black")
        Login_box.place(x=150,y=150,height=340,width=500)
        
        #=============Login details============
        title=Label(Login_box,text="Admin Login Page",font=("",30,"italic"),bg="black",fg="blue").place(x=90,y=30)

        #===========username================

        username=Label(Login_box,text="Username",font=("",15,"italic"),bg="black",fg="white").place(x=90,y=110)
        self.input_username=Entry(Login_box,font=("times new roman",15),fg="white",bg="gray")
        self.input_username.place(x=90,y=140,width=300,height=35)

        #==========Password================

        Password=Label(Login_box,text="Password",font=("",15,"italic"),bg="black",fg="white").place(x=90,y=180)
        self.input_Passwrd=Entry(Login_box,font=("times new roman",15),fg="white",bg="gray")
        self.input_Passwrd.place(x=90,y=210,width=300,height=35)

        #=========forget_passwrd============

        forget=Button(Login_box,text="Forget password",bg="white",fg="red",font=("",10,"bold"))
        forget.place(x=90,y=260)
        #===========Login_button===========

        Login=Button(Login_box,text="Login",bg="white",fg="red",font=("",13,"bold"))
        Login.place(x=90,y=300)

root=Tk()
obj=Login(root)
root.mainloop()    




