import mysql.connector
import mysql.connector as sqltor
mycon=sqltor.connect(host="localhost ",user="root",password="nithish",database="nithish")
if mycon.is_connected()==True:
    print("success!!!!")



    
